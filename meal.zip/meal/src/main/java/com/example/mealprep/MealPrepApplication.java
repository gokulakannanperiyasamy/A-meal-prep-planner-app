package com.example.mealprep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealPrepApplication {
    public static void main(String[] args) {
        SpringApplication.run(MealPrepApplication.class, args);
    }
}
